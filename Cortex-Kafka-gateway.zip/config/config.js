var JSONConfigs =  require('./config.json');

console.log(typeof JSONConfigs)

// let conf = JSON.parse(JSONConfigs);


exports.configs = JSONConfigs;
// exports.conf = conf;