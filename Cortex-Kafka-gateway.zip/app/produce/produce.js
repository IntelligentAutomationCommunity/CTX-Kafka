// start the rest api

const { CompressionTypes } = require('kafkajs');
const kafkaLoader = require('../kafka');

async function produce( topic, messages, acks = -1, timeout = 3000, compression = CompressionTypes.None){

    const kafka = await kafkaLoader.load();

    const producer = kafka.producer();
    
    await producer.connect()

    console.log("Kafka producer connected")

    await producer.send({
        topic: topic,
		messages: messages,
		acks: acks,
		timeout: timeout,
		compression: compression
    })

    await producer.disconnect()
}

exports.produce = produce;
