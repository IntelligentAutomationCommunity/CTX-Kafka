var https = require('https');
const { configs } = require('../../config/config');


// build authorization header

let auth = configs.Cortex.authorization;

let credentialString = auth.username+':'+auth.password;

let buff = Buffer.from(credentialString);

let authHeader = auth.type + ' ' + buff.toString('base64');


// pre-build request body


let body = {
  "Name": configs.Cortex.flow,
  "Initiator": configs.Cortex.initiator,
  "Arguments": {  }
}

if(configs.Cortex.showToken) body.Arguments._CTXSHOWTOKEN=true;


// pre-build request options

let protocol;

configs.Cortex.api.https ? protocol = "https://" : protocol = "http://";

let path = '/api/flow/startflow';
if(configs.Cortex.api.async) path = path+'async';

const options = {
  hostname: configs.Cortex.api.server,
  port: configs.Cortex.api.port,
  path: path,
  method: configs.Cortex.api.verb,
  headers: {
    'Content-Type': configs.Cortex.api.contentType,
    'Authorization': authHeader
  }
}


// exported notify function

async function notify(message){

  body.Arguments.message = message;

  // options.headers['Content-Length'] = body.length;

  const req = https.request(options, res => {
	res.on('data', d => {
      
    })
  })
  
  req.on('error', error => {
    console.error(error)
  })
  
  req.write(JSON.stringify(body))
  req.end()
}

exports.notify = notify;
