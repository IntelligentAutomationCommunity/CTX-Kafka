const kafkaLoader = require('../kafka');
const cortex = require('./notify');
const {configs} = require('../../config/config')



async function consume(){

    let kafka = await kafkaLoader.load();

    const consumer = kafka.consumer({ groupId: configs.kafka.consumer.groupId })

    let topics = configs.kafka.consumer.topics;

    await consumer.connect().then((val)=>console.log("connection", val))

    console.log("Kafka consumer connected")
    
    for(let i=0; i<topics.length ; i++) {
        await consumer.subscribe(topics[i]) 
    };

    console.log("Kafka consumer completed subscription")

    await consumer.run({
    eachMessage: async ({ topic, partition, message }) => {
        

        let msg = {
            topic: topic,
            partition: partition,
            timestamp: message.timestamp,
            offset: message.offset,
            headers: message.headers,
            key: message.key? message.key.toString() : '',
            value: message.value ? message.value.toString() : '',
            size: message.size,
            attributes: message.attributes
        }

        console.log('Received message from Kafka on topic '+msg.topic+': '+ msg.value)

        cortex.notify(msg);


    },
    })
}


exports.startConsuming = consume;